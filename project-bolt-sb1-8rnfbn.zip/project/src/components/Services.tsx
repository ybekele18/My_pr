import React from 'react';
import { Code, Video, Image, Music } from 'lucide-react';

const services = [
  {
    icon: Code,
    title: 'Web Development',
    description: 'Custom websites and web applications built with modern technologies.'
  },
  {
    icon: Video,
    title: 'Video Editing',
    description: 'Professional video editing for all your content needs.'
  },
  {
    icon: Image,
    title: 'Photo Editing',
    description: 'High-quality photo editing and enhancement services.'
  },
  {
    icon: Music,
    title: 'Music Arrangement',
    description: 'Professional music arrangement and production services.'
  }
];

export default function Services() {
  return (
    <div className="min-h-[calc(100vh-200px)] p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-12">My Services</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition-colors"
            >
              <service.icon className="w-12 h-12 text-blue-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
              <p className="text-gray-400">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}