import React from 'react';

function Welcome({ onGetStarted }) {
  return (
    <div className="min-h-[calc(100vh-200px)] flex flex-col items-center justify-center p-8">
      <div className="max-w-3xl text-center space-y-8">
        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
          Welcome to My Website
        </h1>
        <p className="text-xl text-gray-300 leading-relaxed">
          I'm Yared Bekele, a student at Addis Ababa University passionate about web development,
          video editing, and creative solutions. With expertise in multiple digital domains,
          I'm here to bring your ideas to life.
        </p>
        <button
          onClick={onGetStarted}
          className="inline-flex items-center px-6 py-3 rounded-full bg-blue-500 hover:bg-blue-600 transition-colors"
        >
          Get Started
        </button>
      </div>
    </div>
  );
}

export default Welcome;