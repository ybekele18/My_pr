import React, { useState } from 'react';
import Welcome from './components/Welcome';
import Auth from './components/Auth';
import Services from './components/Services';

function App() {
  const [currentPage, setCurrentPage] = useState('welcome');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const renderPage = () => {
    switch(currentPage) {
      case 'welcome':
        return <Welcome onGetStarted={() => setCurrentPage('auth')} />;
      case 'auth':
        return <Auth onAuthSuccess={() => {
          setIsAuthenticated(true);
          setCurrentPage('services');
        }} />;
      case 'services':
        return isAuthenticated ? <Services /> : setCurrentPage('auth');
      default:
        return <Welcome onGetStarted={() => setCurrentPage('auth')} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      {renderPage()}
      
      <footer className="bg-gray-900 py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="space-y-2 text-center md:text-left mb-4 md:mb-0">
              <h3 className="text-xl font-bold">Help Center</h3>
              <div>📱 Phone: +251942823656</div>
              <div>📱 Telegram: @ybekele18</div>
              <div>📧 Email: ybekele18@gmail.com</div>
            </div>
            <div className="text-sm text-gray-400">
              © {new Date().getFullYear()} Yared Bekele. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;